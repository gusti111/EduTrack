import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../app/theme/app_colors.dart';
import '../models/notification_type.dart';

/// Pilihan warna aksen tema — mengubah `seedColor` Material di seluruh
/// app (lihat AppTheme.light/dark & app.dart), sesuai menu "Tema Warna"
/// pada Figma.
enum AppAccentColor { ungu, biru, hijau, oranye, merahMuda }

extension AppAccentColorX on AppAccentColor {
  String get label => switch (this) {
        AppAccentColor.ungu => 'Ungu',
        AppAccentColor.biru => 'Biru',
        AppAccentColor.hijau => 'Hijau',
        AppAccentColor.oranye => 'Oranye',
        AppAccentColor.merahMuda => 'Merah Muda',
      };

  Color get color => switch (this) {
        AppAccentColor.ungu => AppColors.primary,
        AppAccentColor.biru => const Color(0xFF2F80ED),
        AppAccentColor.hijau => const Color(0xFF27AE60),
        AppAccentColor.oranye => const Color(0xFFF2994A),
        AppAccentColor.merahMuda => const Color(0xFFEB5B8C),
      };
}

/// 3 zona waktu Indonesia — dipakai TimezoneScreen & (nantinya) buat
/// menampilkan jam lokal user di luar WIB.
const List<String> kTimezoneOptions = [
  'Waktu Indonesia Barat (WIB)',
  'Waktu Indonesia Tengah (WITA)',
  'Waktu Indonesia Timur (WIT)',
];

/// Preset nada dering notifikasi (belum ada file audio sungguhan di
/// project ini — ini murni preferensi yang dipersist, siap disambungkan
/// ke package seperti `audioplayers` kalau assetnya sudah tersedia).
const List<String> kRingtoneOptions = [
  'Default',
  'Chime',
  'Bell',
  'Marimba',
  'Ping',
  'Tanpa Suara',
];

/// Kategori notifikasi yang bisa dimatikan/dinyalakan satu-satu di
/// NotificationSettingsScreen, sejajar dengan chip filter di
/// NotificationScreen (lihat [NotificationFilter]).
const List<NotificationFilter> kToggleableCategories = [
  NotificationFilter.tugas,
  NotificationFilter.jadwal,
  NotificationFilter.pengingat,
  NotificationFilter.sistem,
];

/// Menyimpan seluruh preferensi lokal aplikasi (bukan data akun) —
/// notifikasi, tema warna, bahasa, dan zona waktu — dipersist ke
/// SharedPreferences supaya bertahan antar sesi tanpa perlu backend.
class SettingsProvider extends ChangeNotifier {
  static const _kNotificationsEnabled = 'settings_notifications_enabled';
  static const _kSoundEnabled = 'settings_sound_enabled';
  static const _kVibrationEnabled = 'settings_vibration_enabled';
  static const _kRingtone = 'settings_ringtone';
  static const _kCategoryPrefix = 'settings_category_'; // + nama filter
  static const _kAccentColor = 'settings_accent_color';
  static const _kLanguage = 'settings_language';
  static const _kTimezone = 'settings_timezone';

  bool _notificationsEnabled = true;
  bool _soundEnabled = true;
  bool _vibrationEnabled = true;
  String _ringtone = kRingtoneOptions.first;
  final Map<NotificationFilter, bool> _categoryEnabled = {
    for (final c in kToggleableCategories) c: true,
  };
  AppAccentColor _accentColor = AppAccentColor.ungu;
  String _language = 'Bahasa Indonesia';
  String _timezone = kTimezoneOptions.first;

  bool _loaded = false;

  SettingsProvider() {
    _load();
  }

  bool get isLoaded => _loaded;
  bool get notificationsEnabled => _notificationsEnabled;
  bool get soundEnabled => _soundEnabled;
  bool get vibrationEnabled => _vibrationEnabled;
  String get ringtone => _ringtone;
  AppAccentColor get accentColor => _accentColor;
  String get language => _language;
  String get timezone => _timezone;

  bool isCategoryEnabled(NotificationFilter filter) =>
      _categoryEnabled[filter] ?? true;

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();

    _notificationsEnabled = prefs.getBool(_kNotificationsEnabled) ?? true;
    _soundEnabled = prefs.getBool(_kSoundEnabled) ?? true;
    _vibrationEnabled = prefs.getBool(_kVibrationEnabled) ?? true;
    _ringtone = prefs.getString(_kRingtone) ?? kRingtoneOptions.first;

    for (final category in kToggleableCategories) {
      _categoryEnabled[category] =
          prefs.getBool('$_kCategoryPrefix${category.name}') ?? true;
    }

    final savedAccentIndex = prefs.getInt(_kAccentColor);
    if (savedAccentIndex != null &&
        savedAccentIndex < AppAccentColor.values.length) {
      _accentColor = AppAccentColor.values[savedAccentIndex];
    }

    _language = prefs.getString(_kLanguage) ?? 'Bahasa Indonesia';
    _timezone = prefs.getString(_kTimezone) ?? kTimezoneOptions.first;

    _loaded = true;
    notifyListeners();
  }

  Future<void> setNotificationsEnabled(bool value) async {
    _notificationsEnabled = value;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_kNotificationsEnabled, value);
  }

  Future<void> setSoundEnabled(bool value) async {
    _soundEnabled = value;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_kSoundEnabled, value);
  }

  Future<void> setVibrationEnabled(bool value) async {
    _vibrationEnabled = value;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_kVibrationEnabled, value);
  }

  Future<void> setRingtone(String value) async {
    _ringtone = value;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kRingtone, value);
  }

  Future<void> setCategoryEnabled(NotificationFilter filter, bool value) async {
    _categoryEnabled[filter] = value;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('$_kCategoryPrefix${filter.name}', value);
  }

  Future<void> setAccentColor(AppAccentColor value) async {
    _accentColor = value;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_kAccentColor, value.index);
  }

  Future<void> setLanguage(String value) async {
    _language = value;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kLanguage, value);
  }

  Future<void> setTimezone(String value) async {
    _timezone = value;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kTimezone, value);
  }
}
