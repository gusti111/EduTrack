# Catatan Perbaikan Bug — EduTrack

## 🆕 HOTFIX (setelah laporan pengguna: tombol "Simpan" macet loading di Web)

### 6. Firestore persistence bikin operasi tulis macet selamanya di Flutter Web
**Gejala yang dilaporkan:** di layar Edit Profil (dan berpotensi di semua
layar dengan tombol simpan/tambah/hapus tugas), tombol menampilkan
spinner loading yang **tidak pernah selesai** — tanpa pesan error apapun
di console.

**Akar masalah:** ini regresi dari perbaikan #3 (persistence offline) di
bagian sebelumnya. Ternyata `Settings(persistenceEnabled: true)` punya
masalah yang sudah dilaporkan resmi ke tim Firebase **khusus di Flutter
Web**:
- Harus jadi panggilan Firestore yang PERTAMA setelah app start.
- Bentrok dengan hot reload/hot restart saat development (`flutter run -d
  chrome`), memicu error "Firestore has already been started and
  persistence can no longer be enabled".
- Pada beberapa kasus (flutterfire#17643, flutterfire#12553), operasi
  `set()`/`update()` **macet selamanya tanpa melempar exception apapun** —
  persis gejala yang dilaporkan.

**Perbaikan:**
- `firestore_service.dart`: persistence sekarang hanya diaktifkan di
  platform native (`if (!kIsWeb)`), karena di mobile/desktop fitur ini
  stabil dan tidak punya masalah di atas. Web app pada praktiknya nyaris
  selalu online, jadi cache offline tidak sekritis di sana.
- `firestore_service.dart` & `auth_service.dart`: semua operasi tulis
  (`addTask`, `updateTask`, `deleteTask`, `createUserDoc`, `getUserDoc`,
  `updateUserDoc`) sekarang dibungkus `.timeout(Duration(seconds: 15))`
  sebagai pengaman tambahan — kalau SDK/backend macet karena alasan
  apapun di masa depan, UI akan tetap dapat error yang jelas dalam waktu
  wajar, bukan spinner selamanya.
- `app_exception.dart` & `failure.dart`: menambahkan penanganan khusus
  `TimeoutException` dengan pesan "Permintaan butuh waktu terlalu lama.
  Periksa koneksi internet kamu lalu coba lagi." — dan `NetworkFailure`
  sekarang bisa menerima pesan kustom (sebelumnya hardcoded satu pesan
  saja).

---

Dokumen ini berisi daftar semua bug/error yang ditemukan lewat code review
manual menyeluruh dan sudah diperbaiki di source ini.

## 🔴 Bug kritis (menyebabkan crash)

### 1. Firebase diinisialisasi dua kali (`lib/main.dart`)
**Sebelum:** `main.dart` memanggil `WidgetsFlutterBinding.ensureInitialized()`
dan `Firebase.initializeApp()` sendiri, lalu memanggil `bootstrap()` yang
melakukan hal yang sama persis sekali lagi.
**Akibat:** Firebase App default hanya boleh diinisialisasi sekali —
inisialisasi ganda melempar `FirebaseException [core/duplicate-app]` dan
**aplikasi crash setiap kali dijalankan**.
**Perbaikan:** `main.dart` sekarang hanya memanggil `await bootstrap();`.

## 🟠 Bug logika (fungsi tidak bekerja sesuai maksud)

### 2. Pesan error login/register tidak pernah muncul (`lib/core/errors/app_exception.dart`)
**Sebelum:** urutan pengecekan `if (error is FirebaseException)` diletakkan
sebelum `if (error is FirebaseAuthException)`. Karena `FirebaseAuthException`
adalah subclass dari `FirebaseException`, blok kedua tidak pernah tercapai.
**Akibat:** semua error auth (password salah, email sudah terdaftar, dll)
selalu menampilkan pesan generic "Kesalahan Firestore" alih-alih pesan
ramah berbahasa Indonesia yang sudah disiapkan.
**Perbaikan:** urutan pengecekan ditukar — `FirebaseAuthException` dicek
lebih dulu.

### 3. Cache offline dinonaktifkan padahal dimaksudkan aktif (`lib/core/services/firestore_service.dart`)
**Sebelum:** `persistenceEnabled: false`, padahal komentar di atasnya
menjelaskan tujuannya "supaya task tetap bisa dibaca saat offline".
**Akibat:** fitur offline yang didukung `ConnectivityProvider` tidak
benar-benar berfungsi — task tidak bisa dibaca saat tidak ada koneksi.
**Perbaikan:** diubah ke `persistenceEnabled: true`.

### 4. Profil tidak refresh setelah diedit (`lib/screens/profile/profile_screen.dart`)
**Sebelum:** `FutureBuilder` memanggil `authRepository.getUserProfile(uid)`
langsung di dalam `build()`, sehingga Future baru dibuat di setiap rebuild
(anti-pattern, request Firestore berulang) dan setelah kembali dari
`EditProfileScreen`, nama yang baru disimpan tidak langsung muncul.
**Perbaikan:** direfactor menjadi `StatefulWidget` dengan Future yang
disimpan di State, dan otomatis reload setelah `EditProfileScreen`
mengembalikan `true` (sukses simpan).

### 5. Detail tugas menampilkan nama enum mentah (`lib/screens/tasks/task_detail_screen.dart`)
**Sebelum:** `task.priority.name` / `task.status.name` menampilkan nilai
enum mentah (mis. `inProgress`) alih-alih label berbahasa Indonesia,
tidak konsisten dengan tampilan di layar lain.
**Perbaikan:** diganti menjadi `task.priority.label` / `task.status.label`.

## 🧹 Pembersihan (tidak mempengaruhi fungsi, tapi bagian dari "bug" struktural)

- Menghapus folder sampah `lib/screens/{home,statistics,profile,calendar}`
  dan `lib/screens/{notification,settings,about}` — sisa dari perintah
  `mkdir` dengan brace-expansion yang gagal dieksekusi.
- Menghapus 8 file stub 0-byte yang tidak pernah dipakai di manapun:
  `context_extension.dart`, `string_extension.dart`, `formatter.dart`,
  `helper.dart`, `asset_paths.dart`, `app_bar.dart`, `custom_button.dart`,
  `custom_card.dart`. Sudah diverifikasi tidak ada import yang menunjuk
  ke file-file ini.
- Menormalkan line ending CRLF → LF pada `push_notification_service.dart`,
  `task_card.dart`, dan `analysis_options.yaml`.

## ⚠️ Keterbatasan verifikasi

Environment yang saya pakai untuk mengedit tidak memiliki Flutter/Dart SDK
terpasang (dan tidak bisa mengunduhnya karena jaringan dibatasi ke domain
tertentu), sehingga saya **tidak bisa menjalankan `flutter analyze` atau
`flutter test`** untuk verifikasi otomatis. Semua temuan di atas didasarkan
pada code review manual baris-demi-baris, termasuk verifikasi silang semua
import antar file. Saya sangat menyarankan menjalankan:

```bash
flutter pub get
flutter analyze
flutter test
```

di mesin lokal Anda (yang punya Flutter SDK) sebagai langkah verifikasi
akhir sebelum build/release.

## 💡 Rekomendasi visual (belum diterapkan, sesuai catatan Anda)

Anda menyebutkan sisi visual masih kurang. Kode saat ini fungsional
sepenuhnya tapi memakai widget Material standar tanpa banyak polish
(tidak ada ilustrasi/asset kustom di `assets/icons` & `assets/illustrations`
yang saat ini kosong, tidak ada animasi transisi, dsb). Kalau Anda mau,
saya bisa lanjutkan ke perbaikan visual (spacing, warna, ilustrasi empty
state, custom app bar, dll) di percakapan berikutnya — cukup beri tahu
bagian mana yang ingin diprioritaskan.
