import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart' show kIsWeb;

import '../../app/constants/firestore_paths.dart';

/// Lapisan paling bawah: hanya tahu soal Firestore, tidak tahu soal
/// TaskModel atau Failure. Kalau nanti backend berganti, cukup file ini
/// (dan implementasinya di Repository) yang disentuh.
class FirestoreService {
  FirestoreService({FirebaseFirestore? firestore})
      : _firestore = firestore ?? FirebaseFirestore.instance {
    // Persistent cache HANYA diaktifkan di platform native (Android/iOS/
    // desktop), bukan di Flutter Web.
    //
    // Kenapa: di Web, `Settings.persistenceEnabled` punya beberapa masalah
    // yang sudah dilaporkan resmi ke tim Firebase — harus jadi panggilan
    // PERTAMA ke Firestore, bentrok dengan hot reload/hot restart saat
    // development ("Firestore has already been started and persistence
    // can no longer be enabled"), dan pada beberapa kasus membuat
    // operasi read/write MACET SELAMANYA tanpa melempar exception apapun
    // (lihat flutterfire#17643, flutterfire#12553). Ini persis gejala
    // tombol "Simpan" yang berputar terus tanpa pernah selesai.
    //
    // Web app pada praktiknya nyaris selalu online, jadi cache offline
    // tidak sekritis dibanding di mobile — aman untuk dilewati di sini.
    if (!kIsWeb) {
      _firestore.settings = const Settings(
        persistenceEnabled: true,
        cacheSizeBytes: Settings.CACHE_SIZE_UNLIMITED,
      );
    }
  }

  final FirebaseFirestore _firestore;

  // Batas waktu wajar untuk operasi tulis. Kalau backend/SDK macet tanpa
  // melempar exception (kasus nyata yang pernah terjadi di atas), user
  // tetap dapat pesan error yang jelas alih-alih tombol loading selamanya.
  static const Duration _writeTimeout = Duration(seconds: 15);

  CollectionReference<Map<String, dynamic>> get _tasksRef =>
      _firestore.collection(FirestorePaths.tasks);

  /// Stream realtime task milik satu user, diurutkan berdasarkan tenggat.
  Stream<QuerySnapshot<Map<String, dynamic>>> watchTasks(String uid) {
    return _tasksRef
        .where(FirestorePaths.fieldUid, isEqualTo: uid)
        .orderBy(FirestorePaths.fieldDueDate)
        .snapshots();
  }

  Future<DocumentReference<Map<String, dynamic>>> addTask(
    Map<String, dynamic> data,
  ) {
    return _tasksRef.add(data).timeout(_writeTimeout);
  }

  Future<void> updateTask(String taskId, Map<String, dynamic> data) {
    return _tasksRef.doc(taskId).update(data).timeout(_writeTimeout);
  }

  Future<void> deleteTask(String taskId) {
    return _tasksRef.doc(taskId).delete().timeout(_writeTimeout);
  }
}
