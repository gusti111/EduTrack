# EduTrack — Scaffold Arsitektur + Slice Task CRUD

Ini hasil scaffolding sesuai `EduTrack_Arsitektur_Revisi.md`, plus satu fitur
lengkap end-to-end (**Task CRUD**) sebagai contoh nyata gimana semua lapisan
dipakai bareng.

## Yang sudah jadi

```
lib/
├── main.dart                          # entry point tipis
├── bootstrap.dart                     # init Firebase, dotenv, error handling
├── firebase_options.dart              # PLACEHOLDER — lihat catatan di bawah
│
├── app/
│   ├── app.dart                       # MultiProvider + MaterialApp
│   ├── theme/app_theme.dart
│   └── constants/firestore_paths.dart
│
├── core/
│   ├── errors/
│   │   ├── failure.dart               # Failure sealed class
│   │   └── app_exception.dart         # mapExceptionToFailure()
│   ├── services/
│   │   ├── auth_service.dart
│   │   └── firestore_service.dart
│   ├── extensions/date_time_extension.dart
│   └── widgets/
│       ├── loading_widget.dart
│       ├── empty_state.dart
│       ├── error_state.dart
│       └── task_card.dart
│
├── models/
│   ├── user_model.dart
│   ├── task_priority.dart             # enum, bukan String bebas
│   ├── task_status.dart
│   └── task_model.dart                # fromMap / toMap / copyWith
│
├── repositories/
│   ├── auth_repository.dart           # interface + AuthRepositoryImpl
│   └── task_repository.dart           # interface + TaskRepositoryImpl
│
├── providers/
│   ├── auth_provider.dart             # state: status (unknown/auth/unauth)
│   └── task_provider.dart             # state: isLoading / tasks / failure
│
└── screens/
    ├── splash/splash_screen.dart      # AuthGate: routing berdasar status
    ├── auth/
    │   ├── login_screen.dart
    │   ├── register_screen.dart
    │   └── forgot_password_screen.dart
    ├── home/
    │   ├── home_shell.dart            # bottom nav: Home/Tasks/Calendar/Statistics/Profile
    │   └── home_screen.dart           # dashboard: stat cards + upcoming tasks
    ├── tasks/
    │   ├── task_list_screen.dart
    │   ├── add_edit_task_screen.dart
    │   └── task_detail_screen.dart
    ├── calendar/calendar_screen.dart  # tasks dikelompokkan per tanggal (versi dasar)
    ├── statistics/statistics_screen.dart  # breakdown status/prioritas, progress bar manual
    ├── notification/notification_screen.dart
    ├── settings/settings_screen.dart
    ├── about/about_screen.dart
    └── profile/
        ├── profile_screen.dart
        └── edit_profile_screen.dart
```

## Alur Auth

`SplashScreen` bertindak sebagai **AuthGate** — satu-satunya tempat yang
"tahu" soal `AuthStatus`:

```
AuthStatus.unknown          -> CircularProgressIndicator
AuthStatus.unauthenticated  -> LoginScreen (-> RegisterScreen / ForgotPasswordScreen)
AuthStatus.authenticated    -> HomeShell(uid: auth.uid!)
```

`uid: 'demo-uid'` yang sebelumnya hardcode di `app.dart` sudah dihapus —
sekarang datang dari `AuthProvider.uid` yang asli, hasil listen ke
`FirebaseAuth.authStateChanges()`. Register otomatis bikin dokumen profil
di koleksi `users` (terpisah dari data auth Firebase sendiri), sesuai
`FirestorePaths.users`.

Validasi form auth mengikuti pola dari Jobsheet 6: email pakai `RegExp`,
password wajib kombinasi huruf besar/kecil + angka, `obscureText` untuk
field password, dan `_formKey.currentState!.validate()` sebelum submit.

## HomeShell (Bottom Navigation)

`HomeShell` memanggil `listenToTasks(uid)` sekali di level shell, lalu
semua tab (Home, Tasks, Calendar, Statistics) baca data yang sama dari
`TaskProvider` — tidak ada subscribe berulang tiap pindah tab (`IndexedStack`
menjaga semua tab tetap hidup di memori).

- **Home** — kartu ringkasan (total/selesai/terlambat) + 5 tugas terdekat.
- **Calendar** — versi dasar: task dikelompokkan per tanggal tenggat sebagai
  daftar section. Bukan grid kalender interaktif — kalau butuh itu, tinggal
  pasang package `table_calendar` sebagai lapisan tampilan; data dari
  `TaskProvider` tidak perlu diubah.
- **Statistics** — breakdown per status & prioritas pakai
  `LinearProgressIndicator` manual (tanpa dependency chart tambahan).
- **Profile** — baca dokumen `users/{uid}` lewat `AuthRepository.getUserProfile()`,
  tombol Edit Profil (ubah `displayName`) dan Keluar.

Alurnya persis seperti diagram di dokumen arsitektur:

```
TaskListScreen (UI)
   → context.watch<TaskProvider>()          # loading / data / failure
      → TaskRepository (interface)          # translate Map ↔ TaskModel
         → FirestoreService                 # panggilan mentah Firestore
```

UI (`task_list_screen.dart`) tidak pernah tahu soal `Firestore` atau
`FirebaseException` — hanya tahu tiga kondisi: loading, ada data, atau ada
`Failure`.

## Yang masih perlu kamu lakukan

1. **Buat project Flutter asli**, lalu timpa folder `lib/` dan `pubspec.yaml`
   dengan yang ada di sini:
   ```
   flutter create edutrack
   ```
2. **Generate `firebase_options.dart` yang asli**:
   ```
   dart pub global activate flutterfire_cli
   flutterfire configure
   ```
   File placeholder di sini sengaja melempar error kalau belum diganti, biar
   ketahuan kalau lupa.
3. `flutter pub get`
4. Aktifkan **Email/Password sign-in** di Firebase Console (Authentication →
   Sign-in method) — tanpa ini, login/register akan gagal dengan error dari
   Firebase.
5. Semua 15 layar di peta Figma sudah punya file. Yang masih placeholder /
   perlu ditingkatkan:
   - **Notifikasi** saat ini IN-APP saja (baca dari koleksi `notifications`
     di Firestore). Untuk push notification beneran (muncul walau app
     tertutup), tambahkan `firebase_messaging` + `flutter_local_notifications`
     — cukup perluas `notification_service.dart`, lapisan di atasnya tidak
     perlu berubah.
   - **Settings** (mode gelap, toggle notifikasi) masih state lokal, belum
     persist. Untuk persist antar sesi, pakai `SharedPreferences`
     (Jobsheet 12) lewat `SettingsProvider` + `ThemeProvider` terpisah.
   - **Calendar** masih versi list-dikelompokkan-per-tanggal, belum grid
     kalender interaktif (lihat catatan di `calendar_screen.dart`).

## Kenapa struktur ini "aman" untuk skala portofolio/UAS

- Enum `TaskPriority`/`TaskStatus` bikin compiler menegur kalau ada state yang
  lupa di-handle di UI (mis. lupa kasih warna untuk `overdue`).
- `Failure` terpusat → semua layar bisa pakai `ErrorState` yang sama, tidak
  ada lagi `try/catch` yang isinya cuma `print(e)`.
- Kalau nanti mau migrasi ke Riverpod atau ganti backend, cukup
  `TaskProvider`/`TaskRepositoryImpl` yang disentuh — model, UI, dan Service
  tidak perlu diubah.
